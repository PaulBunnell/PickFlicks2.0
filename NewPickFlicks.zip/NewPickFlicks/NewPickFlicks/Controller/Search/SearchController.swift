//
//  SearchController.swift
//  NewPickFlicks
//
//  Created by John Padilla on 3/17/21.
//

import UIKit

class SearchController: UIViewController {
    
    //MARK: - Properties
    
    
    //MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = #colorLiteral(red: 0.1610715091, green: 0.1607382596, blue: 0.1691181064, alpha: 1)
    }
}
