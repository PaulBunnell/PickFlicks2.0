//
//  Service.swift
//  NewPickFlicks
//
//  Created by John Padilla on 3/17/21.
//

import Foundation
